const C3 = self.C3;
self.C3_GetObjectRefTable = function () {
	return [
		C3.Plugins.Sprite,
		C3.Behaviors.EightDir,
		C3.Behaviors.scrollto,
		C3.Behaviors.solid,
		C3.Behaviors.Bullet,
		C3.Plugins.Text,
		C3.Plugins.Mouse,
		C3.Behaviors.Orbit,
		C3.Behaviors.Sin
	];
};
self.C3_JsPropNameTable = [
	{"8Direções": 0},
	{CentrarEm: 0},
	{jpgador: 0},
	{chave: 0},
	{portaa: 0},
	{Sólido: 0},
	{piso: 0},
	{Projétil: 0},
	{tiroJpgador: 0},
	{tiroInimigo: 0},
	{Texto: 0},
	{Mouse: 0},
	{Órbita: 0},
	{Senóide: 0},
	{inimigo: 0},
	{obstaculo: 0}
];

self.InstanceType = {
	jpgador: class extends self.ISpriteInstance {},
	chave: class extends self.ISpriteInstance {},
	portaa: class extends self.ISpriteInstance {},
	piso: class extends self.ISpriteInstance {},
	tiroJpgador: class extends self.ISpriteInstance {},
	tiroInimigo: class extends self.ISpriteInstance {},
	Texto: class extends self.ITextInstance {},
	Mouse: class extends self.IInstance {},
	inimigo: class extends self.ISpriteInstance {},
	obstaculo: class extends self.ISpriteInstance {}
}